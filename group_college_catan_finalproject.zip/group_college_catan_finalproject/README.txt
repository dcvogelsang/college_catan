College Catan is a college version of the board game The Settlers of Catan.

Import the Minim and ControlP5 Libraries.

Open college_catan.pde and press run.
Select New Game from the menu.
Select how many players the game will have, type the player name in the corresponding text box, and select a player color. Be sure to select different colors for each player.
Press Play Game when ready. 
Follow the instructions for gameplay.
Press Next Player when ready for the next player�s turn.
Game will end when any player collects 6 Victory Points.

Mute the sound by pressing �m� at any point.
To build, press �1� and click on an intersection for a dorm. Press �2� and click on a dorm to upgrade the dorm to an apartment. Press �3� and click on a segment to build a road.

Note: There may be a slight lag with mouse movement.